a=[19,9,13,5,15]

print("the array is")
for i in range(len(a)):
    print("%d" %a[i])

for i in range(1,len(a)):
    temp=a[i]
    j=i-1
     
    while j>=0 and a[j]>temp:
         
        a[j+1]=a[j]
        j=j-1
     
    a[j+1]=temp

print("sorted array is:")
for i in range(len(a)):
    print("%d" %a[i])
    
    
    